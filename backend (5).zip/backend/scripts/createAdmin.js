const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Admin = require('../models/admin.model'); 

mongoose.connect('mongodb://localhost:27017/sss')
  .then(async () => {
    const existing = await Admin.findOne({ email: 'admin@gmail.com' });
    if (existing) {
      console.log('Admin already exists');
      process.exit();
    }

    const hashed = await bcrypt.hash('admin1234', 10);
    const admin = new Admin({
      username: 'SuperAdmin',
      email: 'admin@gmail.com',
      password: hashed
    });

    await admin.save();
    console.log('Admin created');
    process.exit();
  })
  .catch(err => {
    console.error('DB error', err);
    process.exit(1);
  });
