const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');

const authRoutes = require('./routes/auth.routes');
const orderRoutes = require('./routes/order.routes');
const productRoutes = require('./routes/product.routes');

const app = express();
app.use(bodyParser.json());
app.use(cors({ origin: 'http://localhost:4200', credentials: true }));


const mongoURI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/sss';
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ Failed to connect:', err));


const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true }
});
const User = mongoose.models.User || mongoose.model('User', userSchema);

// Order Schema
const orderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [
    {
      name: String,
      price: Number,
      quantity: Number,
      image: String
    }
  ],
  total: Number,
  date: { type: Date, default: Date.now }
});
const Order = mongoose.models.Order || mongoose.model('Order', orderSchema);


app.get('/', (req, res) => {
  res.send('🌐 Welcome to the ProGearZone Backend API');
});


app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ message: '⚠️ All fields are required.' });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: '❌ Email already exists!' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, email, password: hashedPassword });
    const savedUser = await newUser.save();

    res.status(201).json({ message: `✅ Welcome, ${username}! Registration successful.` });
  } catch (error) {
    res.status(500).json({ message: '❌ Registration error', error: error.message });
  }
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: '❌ Invalid email or password.' });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ message: '❌ Invalid email or password.' });

    const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ message: `✅ Welcome, ${user.username}!`, user, token });
  } catch (error) {
    res.status(500).json({ message: '❌ Login error', error: error.message });
  }
});

app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: '❌ Email not registered.' });

    const resetLink = `http://localhost:4200/reset-password?email=${email}`;

    const testAccount = await nodemailer.createTestAccount();
    const transporter = nodemailer.createTransport({
      host: testAccount.smtp.host,
      port: testAccount.smtp.port,
      secure: testAccount.smtp.secure,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass
      }
    });

    const mailOptions = {
      from: '"ProGearZone Support 👟" <no-reply@progearzone.com>',
      to: email,
      subject: '🔐 Password Reset Request',
      html: `<p>Hello ${user.username},</p>
             <p>Click the link below to reset your password:</p>
             <a href="${resetLink}">${resetLink}</a>`
    };

    const info = await transporter.sendMail(mailOptions);
    res.json({
      message: '✅ Password reset link sent to your email.',
      preview: nodemailer.getTestMessageUrl(info)
    });
  } catch (error) {
    res.status(500).json({ message: '❌ Server error.', error: error.message });
  }
});

// Reset Password
app.post('/reset-password', async (req, res) => {
  const { email, newPassword } = req.body;
  if (!email || !newPassword) return res.status(400).json({ message: '⚠️ Email and new password are required.' });

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: '❌ User not found.' });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    res.json({ message: '✅ Password updated successfully.' });
  } catch (error) {
    res.status(500).json({ message: '❌ Server error.', error: error.message });
  }
});

// Place Order
app.post('/orders', async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: '❌ Unauthorized. No token provided.' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { items, total } = req.body;

    const newOrder = new Order({
      userId: decoded.id,
      items,
      total
    });

    await newOrder.save();
    res.status(201).json({ message: '✅ Order placed successfully.' });
  } catch (error) {
    res.status(500).json({ message: '❌ Could not place order.', error: error.message });
  }
});

// Order History
app.get('/orders/history', async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: '❌ Unauthorized. No token provided.' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const orders = await Order.find({ userId: decoded.id }).sort({ date: -1 });

    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: '❌ Could not fetch orders.', error: error.message });
  }
});

app.use('/api/auth', authRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/products', productRoutes);
app.use('/api/admin', require('./routes/admin.routes'));

const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));

