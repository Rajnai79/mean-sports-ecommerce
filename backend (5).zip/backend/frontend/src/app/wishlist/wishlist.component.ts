import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.scss']
})
export class WishlistComponent implements OnInit {
  wishlist: any[] = [];

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedWishlist = localStorage.getItem('wishlist');
    this.wishlist = storedWishlist ? JSON.parse(storedWishlist) : [];
  }

  removeFromWishlist(product: any): void {
    this.wishlist = this.wishlist.filter(item => item.name !== product.name);
    localStorage.setItem('wishlist', JSON.stringify(this.wishlist));
  }

  goToProductDetail(product: any): void {
    const productId = product.id || product.name.toLowerCase().replace(/\s+/g, '-');
    this.router.navigate(['/product', productId]);
  }

  addToCart(product: any): void {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItem = cart.find((item: any) => item.name === product.name);
    if (existingItem) {
      existingItem.quantity++;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${product.name} added to cart!`);
  }
}
