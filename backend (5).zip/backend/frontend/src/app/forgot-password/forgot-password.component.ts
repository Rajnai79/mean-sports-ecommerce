import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent {
  email = '';
  message = '';
  isSuccess = false;
  previewLink = '';

  constructor(private http: HttpClient) {}

  onSubmit() {
    this.http.post<any>('http://localhost:3000/forgot-password', { email: this.email }).subscribe({
      next: (res) => {
        this.message = res.message;
        this.isSuccess = true;
        this.previewLink = res.preview || ''; 
      },
      error: (err) => {
        this.message = err.error.message || '❌ Failed to send reset email.';
        this.isSuccess = false;
      }
    });
  }
}
