import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {
  sportsProducts: any = {};

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedProducts = localStorage.getItem('products');
    this.sportsProducts = storedProducts ? JSON.parse(storedProducts) : {};
  }

  sportsList(): string[] {
    return Object.keys(this.sportsProducts || {});
  }

  addProduct(): void {
    this.router.navigate(['/admin/products/add']);
  }

  editProduct(sport: string, productIndex: number): void {
    this.router.navigate(['/admin/products/edit', `${sport}_${productIndex}`]);
  }

  deleteProduct(sport: string, productIndex: number): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.sportsProducts[sport].splice(productIndex, 1);
      localStorage.setItem('products', JSON.stringify(this.sportsProducts));
      this.ngOnInit(); // reload products
    }
  }
}
