import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.scss']
})
export class ProductFormComponent implements OnInit {
  sportsList: string[] = ['cricket', 'football', 'tennis', 'basketball', 'tableTennis'];
  brandsList: string[] = ['Nike', 'Adidas', 'Puma', 'Reebok', 'Under Armour'];
  categoriesList: string[] = ['Shoes', 'Apparel', 'Equipment', 'Accessories', 'Nutrition'];

  product: Product = {
    name: '',
    price: 0,
    brand: '',
    category: '',
    stock: 0,
    image: '',
    _id: ''
  };

  sport: string = '';
  editMode: boolean = false;
  productIndex: number = -1;
  imagePreview: string | ArrayBuffer | null = null;
  apiUrl: string = 'http://localhost:3000/api/products';

  constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.editMode = true;
      const [sport, index] = id.split('_');
      this.sport = sport;
      this.productIndex = +index;
      this.fetchProduct();
    }
  }

  fetchProduct(): void {
    const productsData = localStorage.getItem('products');
    if (productsData) {
      const allProducts = JSON.parse(productsData);
      const sportProducts = allProducts[this.sport] || [];
      const productToEdit = sportProducts[this.productIndex];

      if (productToEdit) {
        this.product = { ...productToEdit };
        this.imagePreview = this.product.image || null;
      } else {
        alert('Product not found in local storage');
      }
    } else {
      alert('No product data in local storage');
    }
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
        this.product.image = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  saveProduct(): void {
    if (!this.product.name || this.product.price <= 0 || !this.product.category || !this.sport) {
      alert('Please fill in all required fields, including selecting a sport!');
      return;
    }


    const newProduct: Product = {
      ...this.product,
      _id: this.editMode ? this.product._id : `${this.sport}-${Date.now()}`
    };

    if (this.editMode) {
      this.updateLocalStorage(newProduct);
      alert('Product updated successfully!');
      this.router.navigate(['/admin/dashboard']);
    } else {
      this.http.post(this.apiUrl, newProduct).subscribe(
        (response: any) => {
          alert('Product added successfully!');
          this.updateLocalStorage(newProduct);
          this.router.navigate(['/admin/dashboard']);
        },
        () => alert('Error adding product')
      );
    }
  }

  updateLocalStorage(newProduct: Product): void {
    const storedProducts: { [key: string]: Product[] } = JSON.parse(localStorage.getItem('products') || '{}');
    const productList = storedProducts[this.sport] || [];

    if (this.editMode) {
      productList[this.productIndex] = newProduct; // Replace at index
    } else {
      productList.push(newProduct);
    }

    storedProducts[this.sport] = productList;
    localStorage.setItem('products', JSON.stringify(storedProducts));
  }
}
