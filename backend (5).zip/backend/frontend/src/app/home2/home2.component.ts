import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../models/product.model';
import { getSportsProducts } from './product-list';

@Component({
  selector: 'app-home2',
  templateUrl: './home2.component.html',
  styleUrls: ['./home2.component.scss']
})
// export class Home2Component implements OnInit {
//   username: string = 'User';
//   greeting: string = '';
//   cart: (Product & { quantity: number })[] = [];
//   wishlist: Product[] = [];
//   recentlyViewed: Product[] = [];
//   dealProduct: Product | null = null;
//   darkMode: boolean = false;
//   isAdmin: boolean = false;

//   searchQuery: string = '';
//   selectedSport: string = '';
//   selectedBrand: string = 'all';
//   selectedCategory: string = 'all';
//   selectedSort: string = 'name';

//   filteredProducts: Product[] = [];
//   dropdownOpen: boolean = false;

//   sportsList: string[] = ['cricket', 'football', 'tennis', 'basketball', 'tableTennis'];
//   brandsList: string[] = ['Nike', 'Adidas', 'Puma', 'Reebok', 'Under Armour'];

//   sportsProducts: { [key: string]: Product[] } = {};

//   newProduct: Product = {
//     name: '',
//     price: 0,
//     brand: '',
//     category: '',
//     image: 'string',
//     description: '',
//     stock: 0
//   };

//   constructor(private router: Router) {}

//   ngOnInit(): void {
//     const storedUser = localStorage.getItem('username');
//     const storedCart = localStorage.getItem('cart');
//     const storedWishlist = localStorage.getItem('wishlist');
//     const storedProducts = localStorage.getItem('products');
//     const storedIsAdmin = localStorage.getItem('isAdmin');
//     this.sportsProducts = getSportsProducts(); // ✅ Merged products

//     if (!storedUser) {
//       this.router.navigate(['/login']);
//     } else {
//       this.username = storedUser;
//       this.cart = storedCart ? JSON.parse(storedCart) : [];
//       this.wishlist = storedWishlist ? JSON.parse(storedWishlist) : [];
//       this.isAdmin = storedIsAdmin === 'true';
//       this.setGreeting();
//       this.setDealProduct();
//       this.filterProducts();
//     }
//   }

//   setGreeting(): void {
//     const hour = new Date().getHours();
//     this.greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
//   }

//   setDealProduct(): void {
//     const allProducts: Product[] = Object.values(this.sportsProducts).flat();
//     this.dealProduct = allProducts.length > 0 ? allProducts[Math.floor(Math.random() * allProducts.length)] : null;
//   }

//   toggleDarkMode(): void {
//     this.darkMode = !this.darkMode;
//     document.body.classList.toggle('dark-mode', this.darkMode);
//   }

//   toggleDropdown(): void {
//     this.dropdownOpen = !this.dropdownOpen;
//   }

//   closeDropdown(): void {
//     this.dropdownOpen = false;
//   }

//   selectSport(sport: string): void {
//     this.selectedSport = sport;
//     this.selectedCategory = 'all';
//     this.selectedBrand = 'all';
//     this.searchQuery = '';
//     this.filterProducts();
//   }

//   filterProducts(): void {
//     if (!this.selectedSport || !this.sportsProducts[this.selectedSport]) {
//       this.filteredProducts = [];
//       return;
//     }

//     this.filteredProducts = [...this.sportsProducts[this.selectedSport]];

//     if (this.searchQuery.trim()) {
//       this.filteredProducts = this.filteredProducts.filter(product =>
//         product.name.toLowerCase().includes(this.searchQuery.toLowerCase())
//       );
//     }

//     if (this.selectedBrand !== 'all') {
//       this.filteredProducts = this.filteredProducts.filter(product => product.brand === this.selectedBrand);
//     }

//     if (this.selectedCategory !== 'all') {
//       this.filteredProducts = this.filteredProducts.filter(product => product.category === this.selectedCategory);
//     }

//     this.sortProducts();
//   }

//   sortProducts(): void {
//     this.filteredProducts.sort((a, b) =>
//       this.selectedSort === 'price' ? a.price - b.price : a.name.localeCompare(b.name)
//     );
//   }

//   filterByBrand(event: Event): void {
//     const target = event.target as HTMLSelectElement;
//     this.selectedBrand = target.value;
//     this.filterProducts();
//   }

//   filterByCategory(event: Event): void {
//     const target = event.target as HTMLSelectElement;
//     this.selectedCategory = target.value;
//     this.filterProducts();
//   }

//   onSortChange(event: Event): void {
//     const target = event.target as HTMLSelectElement;
//     this.selectedSort = target.value;
//     this.sortProducts();
//   }

//   getCategories(): string[] {
//     if (this.selectedSport && this.sportsProducts[this.selectedSport]) {
//       return Array.from(new Set(
//         this.sportsProducts[this.selectedSport].map((product: Product) => product.category || ''))
//       );
//     }
//     return [];
//   }

//   addToCart(product: Product, event: MouseEvent): void {
//     event.stopPropagation();
//     const existingItem = this.cart.find(item => item.name === product.name);
//     if (existingItem) {
//       existingItem.quantity++;
//     } else {
//       this.cart.push({ ...product, quantity: 1 });
//     }
//     localStorage.setItem('cart', JSON.stringify(this.cart));
//     alert(`${product.name} added to cart!`);
//   }

//   addToWishlist(product: Product, event: MouseEvent): void {
//     event.stopPropagation();
//     if (!this.wishlist.some(item => item.name === product.name)) {
//       this.wishlist.push(product);
//       localStorage.setItem('wishlist', JSON.stringify(this.wishlist));
//       alert(`${product.name} added to wishlist!`);
//     }
//   }

//   goToProfile(): void {
//     this.router.navigate(['/profile']);
//   }

//   updateProfile(): void {
//     this.router.navigate(['/update-profile']);
//   }

//   trackByProduct(index: number, product: Product): string {
//     return product._id || product.name;
//   }

//   goToProductDetail(product: Product): void {
//     const productId = product._id || product.name.toLowerCase().replace(/\s+/g, '-');
//     this.recentlyViewed.unshift(product);
//     this.recentlyViewed = this.recentlyViewed.slice(0, 5);
//     this.router.navigate(['/product', productId]);
//   }

//   logout(): void {
//     localStorage.removeItem('username');
//     localStorage.removeItem('cart');
//     localStorage.removeItem('wishlist');
//     this.router.navigate(['/login']);
//   }
// }
export class Home2Component implements OnInit {
  username: string = 'User';
  greeting: string = '';
  cart: (Product & { quantity: number })[] = [];
  wishlist: Product[] = [];
  recentlyViewed: Product[] = [];
  dealProduct: Product | null = null;
  darkMode: boolean = false;
  isAdmin: boolean = false;

  searchQuery: string = '';
  selectedSport: string = '';
  selectedBrand: string = 'all';
  selectedCategory: string = 'all';
  selectedSort: string = 'name';
  viewMode: 'grid' | 'list' = 'grid';

  filteredProducts: Product[] = [];
  dropdownOpen: boolean = false;

  sportsList: string[] = ['cricket', 'football', 'tennis', 'basketball', 'tableTennis'];
  brandsList: string[] = ['Nike', 'Adidas', 'Puma', 'Reebok', 'Under Armour'];

  sportsProducts: { [key: string]: Product[] } = {};

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedUser = localStorage.getItem('username');
    const storedCart = localStorage.getItem('cart');
    const storedWishlist = localStorage.getItem('wishlist');
    const storedIsAdmin = localStorage.getItem('isAdmin');
    const storedDarkMode = localStorage.getItem('darkMode');

    this.sportsProducts = getSportsProducts();

    if (!storedUser) {
      this.router.navigate(['/login']);
    } else {
      this.username = storedUser;
      this.cart = storedCart ? JSON.parse(storedCart) : [];
      this.wishlist = storedWishlist ? JSON.parse(storedWishlist) : [];
      this.isAdmin = storedIsAdmin === 'true';
      this.darkMode = storedDarkMode ? JSON.parse(storedDarkMode) : false;
      document.body.classList.toggle('dark-mode', this.darkMode);

      this.setGreeting();
      this.setDealProduct();
      this.filterProducts();
    }
  }

  toggleDarkMode(): void {
    this.darkMode = !this.darkMode;
    document.body.classList.toggle('dark-mode', this.darkMode);
    localStorage.setItem('darkMode', JSON.stringify(this.darkMode));
  }

  toggleDropdown(): void {
    this.dropdownOpen = !this.dropdownOpen;
  }

  closeDropdown(): void {
    this.dropdownOpen = false;
  }

  selectSport(sport: string): void {
    this.selectedSport = sport;
    this.selectedCategory = 'all';
    this.selectedBrand = 'all';
    this.searchQuery = '';
    this.filterProducts();
  }

  filterProducts(): void {
    if (!this.selectedSport || !this.sportsProducts[this.selectedSport]) {
      this.filteredProducts = [];
      return;
    }

    this.filteredProducts = [...this.sportsProducts[this.selectedSport]];

    if (this.searchQuery.trim()) {
      this.filteredProducts = this.filteredProducts.filter(product =>
        product.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }

    if (this.selectedBrand !== 'all') {
      this.filteredProducts = this.filteredProducts.filter(product => product.brand === this.selectedBrand);
    }

    if (this.selectedCategory !== 'all') {
      this.filteredProducts = this.filteredProducts.filter(product => product.category === this.selectedCategory);
    }

    this.sortProducts();
  }

  sortProducts(): void {
    this.filteredProducts.sort((a, b) =>
      this.selectedSort === 'price' ? a.price - b.price : a.name.localeCompare(b.name)
    );
  }

  toggleView(mode: 'grid' | 'list') {
    this.viewMode = mode;
  }

  filterByBrand(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedBrand = target.value;
    this.filterProducts();
  }

  filterByCategory(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedCategory = target.value;
    this.filterProducts();
  }

  onSortChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedSort = target.value;
    this.sortProducts();
  }

  getCategories(): string[] {
    if (this.selectedSport && this.sportsProducts[this.selectedSport]) {
      return Array.from(new Set(this.sportsProducts[this.selectedSport].map(p => p.category || '')));
    }
    return [];
  }

  addToCart(product: Product, event: MouseEvent): void {
    event.stopPropagation();
    const existingItem = this.cart.find(item => item.name === product.name);
    if (existingItem) {
      existingItem.quantity++;
    } else {
      this.cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(this.cart));
    alert(`${product.name} added to cart!`);
  }

  addToWishlist(product: Product, event: MouseEvent): void {
    event.stopPropagation();
    if (!this.wishlist.some(item => item.name === product.name)) {
      this.wishlist.push(product);
      localStorage.setItem('wishlist', JSON.stringify(this.wishlist));
      alert(`${product.name} added to wishlist!`);
    }
  }

  goToProductDetail(product: Product): void {
    const productId = product._id || product.name.toLowerCase().replace(/\s+/g, '-');
    this.recentlyViewed.unshift(product);
    this.recentlyViewed = this.recentlyViewed.slice(0, 5);
    this.router.navigate(['/product', productId]);
  }

  goToProfile(): void {
    this.router.navigate(['/profile']);
  }

  updateProfile(): void {
    this.router.navigate(['/update-profile']);
  }

  logout(): void {
    localStorage.removeItem('username');
    localStorage.removeItem('cart');
    localStorage.removeItem('wishlist');
    this.router.navigate(['/login']);
  }

  setGreeting(): void {
    const hour = new Date().getHours();
    this.greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
  }

  setDealProduct(): void {
    const allProducts: Product[] = Object.values(this.sportsProducts).flat();
    this.dealProduct = allProducts.length > 0
      ? allProducts[Math.floor(Math.random() * allProducts.length)]
      : null;
  }

  trackByProduct(index: number, product: Product): string {
    return product._id || product.name;
  }
}
