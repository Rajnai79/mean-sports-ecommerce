import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { Location } from '@angular/common';
import { sportsProducts } from '../product-list';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailComponent implements OnInit {
  product: any;
  reviews: any[] = [];
  newReview: any = { userName: '', rating: 5, comment: '' };
  quantity: number = 1;
  reviewSortOption: string = 'date';
  isLoading: boolean = false;
  errorMessage: string = '';
  productNotFound: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private router: Router,
    private location: Location
  ) {}

  ngOnInit(): void {
    const productSlug = this.route.snapshot.paramMap.get('id')?.toLowerCase();
    if (productSlug) {
      this.getProductDetails(productSlug);
    }
  }

  getProductDetails(slug: string): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.productNotFound = false;

    let found = false;
    for (const sport in sportsProducts) {
      const product = sportsProducts[sport].find((p: any) => {
        const productSlug = p._id || p.name.toLowerCase().replace(/\s+/g, '-');
        return productSlug === slug;
      });

      if (product) {
        this.product = product;
        this.product._id = this.product._id || this.product.name.toLowerCase().replace(/\s+/g, '-');
        found = true;
        this.getProductReviews(this.product._id);
        break;
      }
    }

    if (!found) {
      this.isLoading = false;
      this.productNotFound = true;
      console.warn('Product not found locally');
      this.router.navigate(['/not-found']);
    }
  }

  getProductReviews(productId: string): void {
    this.api.getProductReviews(productId).subscribe({
      next: (reviews: any[]) => {
        this.reviews = reviews;
        this.sortReviews();
        this.isLoading = false;
      },
      error: (err: any) => {
        this.isLoading = false;
        this.errorMessage = 'Unable to load reviews. Please try again later.';
        console.error('Error fetching reviews:', err);
      }
    });
  }

  sortReviews(): void {
    if (this.reviewSortOption === 'rating') {
      this.reviews.sort((a, b) => b.rating - a.rating);
    } else if (this.reviewSortOption === 'date') {
      this.reviews.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }
  }

  submitReview(): void {
    if (!this.isReviewValid()) {
      alert('Please provide both username and comment.');
      return;
    }

    const reviewData = {
      userName: this.newReview.userName,
      rating: this.newReview.rating,
      comment: this.newReview.comment,
      date: new Date().toISOString() 
    };

    this.api.submitReview(this.product._id, reviewData).subscribe({
      next: () => {
        this.reviews.push(reviewData);
        this.sortReviews();
        this.newReview = { userName: '', rating: 5, comment: '' };
      },
      error: (err: any) => {
        console.error('Error submitting review:', err);
        alert('Error submitting your review. Please try again.');
      }
    });
  }

  addToCart(product: any, quantity: number): void {
    if (quantity > product.stock) {
      alert(`Sorry, only ${product.stock} items are in stock.`);
      return;
    }

    this.api.addToCart(product).subscribe({
      next: () => {
        alert(`${product.name} added to cart with ${quantity} quantity`);

      },
      error: (err: any) => {
        console.error('Error adding product to cart:', err);
        alert('Error adding product to cart. Please try again.');
      }
    });
  }

  goBack(): void {
    this.location.back();
  }

  calculateAverageRating(): number {
    if (this.reviews.length === 0) return 0;

    const totalRating = this.reviews.reduce((sum, review) => sum + review.rating, 0);
    return parseFloat((totalRating / this.reviews.length).toFixed(2));
  }

  updateQuantity(): void {
    if (this.quantity > this.product.stock) {
      this.quantity = this.product.stock;
    }
  }

  isReviewValid(): boolean {
    return this.newReview.userName.trim() !== '' && this.newReview.comment.trim() !== '';
  }
}


