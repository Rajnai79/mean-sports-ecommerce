import { Product } from '../models/product.model';

export const sportsProducts: { [key: string]: Product[] } = {
  cricket: [
    {
      _id: "cricket-0",
      name: "Nike Football",
      brand: "Nike",
      category: "Football",
      price: 1200,
      description: "Premium match football designed by Nike for professional games.",
      image: "assets/images/nike-football.png",
      stock: 10
    },
    { _id: "cricket-1", name: "Cricket Bat", price: 150, image: "assets/Images/cricket/images (17).jpeg", category: "Bat", brand: "GM", description: "High-quality GM bat ideal for leather ball cricket.", stock: 15 },
    { _id: "cricket-2", name: "Cricket Kit Bag", price: 120, image: "assets/Images/cricket/images (6).jpeg", category: "Bag", brand: "Shrey", description: "Spacious kit bag for carrying all your cricket gear.", stock: 20 },
    { _id: "cricket-3", name: "Plastic Cricket Set", price: 50, image: "assets/Images/cricket/images (1).jpeg", category: "Set", brand: "Kookaburra", description: "Durable plastic set perfect for casual backyard cricket.", stock: 25 },
    { _id: "cricket-4", name: "Batting Pads", price: 60, image: "assets/Images/cricket/images (3).jpeg", category: "Gear", brand: "Cosco", description: "Protective Cosco batting pads for junior and senior players.", stock: 30 },
    { _id: "cricket-5", name: "Batting Gloves", price: 40, image: "assets/Images/cricket/images (4).jpeg", category: "Gear", brand: "Shrey", description: "Comfortable and durable gloves for secure batting grip.", stock: 18 },
    { _id: "cricket-6", name: "Cricket Stumps Set", price: 55, image: "assets/Images/cricket/images (5).jpeg", category: "Stumps", brand: "Kookaburra", description: "Kookaburra branded wooden stumps with bails.", stock: 12 },
    { _id: "cricket-7", name: "Cricket Backpack", price: 80, image: "assets/Images/cricket/images (15).jpeg", category: "Bag", brand: "SS", description: "Compact backpack for everyday cricket training.", stock: 22 },
    { _id: "cricket-8", name: "Cricket Helmet", price: 90, image: "assets/Images/cricket/download.jpg", category: "Gear", brand: "Masuri", description: "Reliable helmet for head protection during play.", stock: 16 },
    { _id: "cricket-9", name: "Cricket Shoes", price: 70, image: "assets/Images/cricket/images (3).jpeg", category: "Footwear", brand: "Adidas", description: "Comfortable cricket shoes designed for all surfaces.", stock: 14 }
  ],
  football: [
    { _id: "football-0", name: 'Football', price: 50, image: 'assets/Images/football/images (7).jpeg', category: 'Ball', brand: 'Puma', description: "Durable Puma football designed for all types of play.", stock: 20 },
    { _id: "football-1", name: 'Football Kit', price: 75, image: 'assets/Images/football/download (9).jpeg', category: 'Apparel', brand: 'Nike', description: "Nike kit including jersey, shorts, and socks for match days.", stock: 10 },
    { _id: "football-2", name: 'Football', price: 55, image: 'assets/Images/football/images (2).jpeg', category: 'Ball', brand: 'Adidas', description: "FIFA-approved Adidas football with optimal flight stability.", stock: 15 },
    { _id: "football-3", name: 'Football Shoes', price: 60, image: 'assets/Images/football/images (3).jpeg', category: 'Footwear', brand: 'Nike', description: "Nike cleats designed for firm-ground football fields.", stock: 12 },
    { _id: "football-4", name: 'Football Jersey', price: 30, image: 'assets/Images/football/images (4).jpeg', category: 'Apparel', brand: 'Puma', description: "Breathable Puma football jersey for comfort and performance.", stock: 18 },
    { _id: "football-5", name: 'Football Jersey', price: 30, image: 'assets/Images/football/images (5).jpeg', category: 'Apparel', brand: 'Puma', description: "Lightweight football jersey ideal for training or match use.", stock: 25 },
    { _id: "football-6", name: 'Football Shoes', price: 60, image: 'assets/Images/football/images (6).jpeg', category: 'Footwear', brand: 'Adidas', description: "Adidas football shoes with excellent grip and fit.", stock: 14 },
    { _id: "football-7", name: 'Football Shoes', price: 70, image: 'assets/Images/football/images.jpeg', category: 'Footwear', brand: 'Nike', description: "High-performance Nike cleats with superior traction.", stock: 10 },
    { _id: "football-8", name: 'Goalkeeper Gloves', price: 35, image: 'assets/Images/football/download.jpg', category: 'Gear', brand: 'Adidas', description: "Padded goalkeeper gloves for better control and safety.", stock: 8 },
    { _id: "football-9", name: 'Shin Guards', price: 20, image: 'assets/Images/football/download.jpg', category: 'Gear', brand: 'Nike', description: "Protective Nike shin guards with adjustable straps.", stock: 22 }
  ],
  tableTennis: [
    { _id: "tableTennis-0", name: "Table Tennis Racket", price: 30, image: "assets/Images/tableTennis/images (1).jpeg", category: "Racket", brand: "Butterfly", description: "Butterfly racket with high spin and control for players.", stock: 12 },
    { _id: "tableTennis-1", name: "Table Tennis Ball Pack", price: 10, image: "assets/Images/tableTennis/images (7).jpeg", category: "Ball", brand: "Stiga", description: "Pack of 6 tournament-grade table tennis balls.", stock: 20 },
    { _id: "tableTennis-2", name: "Table Tennis Table", price: 300, image: "assets/Images/tableTennis/images.jpeg", category: "Table", brand: "Joola", description: "Sturdy Joola table for professional and recreational play.", stock: 5 },
    { _id: "tableTennis-3", name: "Table Tennis Net", price: 15, image: "assets/Images/tableTennis/images.jpeg", category: "Accessories", brand: "DHS", description: "Clip-on table tennis net easy to set up and remove.", stock: 18 },
    { _id: "tableTennis-4", name: "Table Tennis Shoes", price: 60, image: "assets/Images/tableTennis/images (8).jpeg", category: "Footwear", brand: "Butterfly", description: "Lightweight shoes with excellent grip for quick footwork.", stock: 10 },
    { _id: "tableTennis-5", name: "Table Tennis Kit Bag", price: 40, image: "assets/Images/tableTennis/images (6).jpeg", category: "Bag", brand: "Stiga", description: "Compact kit bag designed to carry all TT essentials.", stock: 15 },
    { _id: "tableTennis-6", name: "Table Tennis Racket Cover", price: 15, image: "assets/Images/tableTennis/download (8).jpeg", category: "Accessories", brand: "Joola", description: "Protective cover to keep your racket dust-free and safe.", stock: 25 },
    { _id: "tableTennis-7", name: "Table Tennis Bat Cleaner", price: 8, image: "assets/Images/tableTennis/download (2).jpeg", category: "Accessories", brand: "Butterfly", description: "Cleaning solution for maintaining rubber performance.", stock: 30 },
    { _id: "tableTennis-8", name: "Table Tennis Shorts", price: 25, image: "assets/Images/tableTennis/images (9).jpeg", category: "Apparel", brand: "Stiga", description: "Comfortable and lightweight shorts for training and matches.", stock: 22 },
    { _id: "tableTennis-9", name: "Table Tennis Shirt", price: 30, image: "assets/Images/tableTennis/images (1).jpeg", category: "Apparel", brand: "Butterfly", description: "Stylish Butterfly shirt made with breathable fabric.", stock: 18 }
  ],
  tennis: [
    { _id: "tennis-0", name: "Wilson Pro Staff Tennis Racket", price: 129.99, image: "assets/Images/tennis/wilson_pro_staff.jpeg", category: "Racket", brand: "Wilson", description: "Tour-level racket with exceptional control and feel.", stock: 8 },
    { _id: "tennis-1", name: "Babolat Pure Drive Tennis Racket", price: 199.99, image: "assets/Images/tennis/babolat_pure_drive.jpeg", category: "Racket", brand: "Babolat", description: "Powerful racket ideal for aggressive baseliners.", stock: 10 },
    { _id: "tennis-2", name: "Head Graphene Speed Racket", price: 179.99, image: "assets/Images/tennis/head_graphene_speed.jpeg", category: "Racket", brand: "Head", description: "Lightweight racket with Graphene for enhanced speed.", stock: 12 },
    { _id: "tennis-3", name: "Yonex Ezone 100 Racket", price: 189.99, image: "assets/Images/tennis/yonex_ezone_100.jpeg", category: "Racket", brand: "Yonex", description: "Balanced racket offering control and spin potential.", stock: 6 },
    { _id: "tennis-4", name: "Dunlop CX 200 Racket", price: 159.99, image: "assets/Images/tennis/dunlop_cx_200.jpeg", category: "Racket", brand: "Dunlop", description: "Great choice for intermediate players seeking control.", stock: 9 },
    { _id: "tennis-5", name: "Wilson US Open Balls", price: 9.99, image: "assets/Images/tennis/wilson_us_open_balls.jpeg", category: "Balls", brand: "Wilson", description: "Official US Open tennis balls for hard courts.", stock: 50 },
    { _id: "tennis-6", name: "Babolat Gold Balls", price: 10.99, image: "assets/Images/tennis/babolat_gold_championship.jpeg", category: "Balls", brand: "Babolat", description: "Durable tennis balls designed for extended play.", stock: 40 },
    { _id: "tennis-7", name: "Head Tour Balls", price: 11.99, image: "assets/Images/tennis/head_tour_balls.jpeg", category: "Balls", brand: "Head", description: "High-performance balls for tournament and practice.", stock: 35 },
    { _id: "tennis-8", name: "Tennis Bag", price: 99.99, image: "assets/Images/tennis/tennis_bag.jpeg", category: "Bag", brand: "Wilson", description: "Spacious tennis bag with separate compartments.", stock: 10 },
    { _id: "tennis-9", name: "Tennis Shoes", price: 89.99, image: "assets/Images/tennis/tennis_shoes.jpeg", category: "Footwear", brand: "Nike", description: "All-court tennis shoes with excellent cushioning.", stock: 15 }
  ],
  basketball: [
    { _id: "basketball-0", name: 'Basketball', price: 60, image: 'assets/Images/basketball/basketball.webp', category: 'Ball', brand: 'Adidas', description: "Durable Adidas basketball for both indoor and outdoor play.", stock: 20 },
    { _id: "basketball-1", name: 'Basketball Shoes - Blue & Pink', price: 130, image: 'assets/Images/basketball/download.jpg', category: 'Footwear', brand: 'Puma', description: "Bold Puma shoes for ultimate grip and agility on the court.", stock: 10 },
    { _id: "basketball-2", name: 'Basketball Shoes - Orange & Green', price: 130, image: 'assets/Images/basketball/download.jpeg', category: 'Footwear', brand: 'Puma', description: "Stylish and supportive footwear for competitive players.", stock: 12 },
    { _id: "basketball-3", name: 'Basketball Hoop - Door Mounted', price: 50, image: 'assets/Images/basketball/download (1).jpeg', category: 'Accessories', brand: 'Spalding', description: "Mini hoop perfect for casual play at home or office.", stock: 15 },
    { _id: "basketball-4", name: 'Basketball Hoop Set', price: 80, image: 'assets/Images/basketball/download (1).jpeg', category: 'Accessories', brand: 'Spalding', description: "Complete hoop set for driveway or backyard games.", stock: 8 },
    { _id: "basketball-5", name: 'Basketball Jersey', price: 40, image: 'assets/Images/basketball/download (1).jpeg', category: 'Apparel', brand: 'Nike', description: "Breathable Nike jersey suitable for games and training.", stock: 18 },
    { _id: "basketball-6", name: 'Basketball Bag', price: 70, image: 'assets/Images/basketball/download (4).jpeg', category: 'Bag', brand: 'Under Armour', description: "Large capacity bag for basketball gear and apparel.", stock: 12 },
    { _id: "basketball-7", name: 'Basketball Net', price: 15, image: 'assets/Images/basketball/images.jpeg', category: 'Accessories', brand: 'Wilson', description: "Heavy-duty basketball net compatible with standard hoops.", stock: 25 },
    { _id: "basketball-8", name: 'Basketball Socks', price: 10, image: 'assets/Images/basketball/download (4).jpeg', category: 'Apparel', brand: 'Nike', description: "Cushioned Nike socks for comfort and support.", stock: 30 },
    { _id: "basketball-9", name: 'Wristbands', price: 5, image: 'assets/Images/basketball/download (3).jpeg', category: 'Accessories', brand: 'Adidas', description: "Moisture-absorbing wristbands for intense basketball play.", stock: 50 }
  ],
};

export function getSportsProducts(): { [key: string]: Product[] } {
  const stored = localStorage.getItem('products');
  if (stored) {
    const localData = JSON.parse(stored);
    // Merge with default data, prioritizing localStorage data
    const merged: { [key: string]: Product[] } = { ...sportsProducts };

    for (const sport in localData) {
      merged[sport] = [...(sportsProducts[sport] || []), ...localData[sport]];
    }

    return merged;
  }

  return sportsProducts;
}
