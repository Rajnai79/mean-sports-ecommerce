import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { Home1Component } from './home1/home1.component';
import { Home2Component } from './home2/home2.component';
import { AboutComponent } from './about/about.component';
import { CartWishlistComponent } from './cart-wishlist/cart-wishlist.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { ProductDetailComponent } from './home2/product-detail/product-detail.component';
import { ProfileComponent } from './profile/profile.component';
import { ProductComparisonComponent } from './product-comparison/product-comparison.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { ThankYouComponent } from './thank-you/thank-you.component';

import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { ProductFormComponent } from './admin/product-form/product-form.component';

import { ApiService } from './api.service';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    Home1Component,
    Home2Component,
    AboutComponent,
    CartWishlistComponent,
    CartComponent,
    PaymentComponent,
    ProductDetailComponent,
    ProfileComponent,
    ProductComparisonComponent,
    WishlistComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    OrderHistoryComponent,
    ThankYouComponent,
    AdminLoginComponent,
    AdminDashboardComponent,
    ProductFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule // Needed for formGroup
  ],
  providers: [ApiService],
  bootstrap: [AppComponent],
})
export class AppModule {}
