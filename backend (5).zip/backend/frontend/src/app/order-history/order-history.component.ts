import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.scss']
})
export class OrderHistoryComponent implements OnInit {
  orderHistory: any[] = [];
  userLoggedIn: boolean = false;

  constructor(private router: Router) { }

  ngOnInit(): void {

    const savedOrders = localStorage.getItem('orderHistory');
    this.orderHistory = savedOrders ? JSON.parse(savedOrders) : [];


    this.userLoggedIn = true;

    if (!this.userLoggedIn) {
      this.router.navigate(['/login']);
    }
  }
}
