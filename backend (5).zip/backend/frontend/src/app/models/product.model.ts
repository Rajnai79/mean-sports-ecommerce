// // // // src/app/models/product.model.ts
// // // export interface Product {
// // //   _id?: string;             // MongoDB assigns an `_id` field by default
// // //   name: string;
// // //   price: number;
// // //   category?: string;
// // //   brand: string;            // ✅ Add this line       // Optional, as it's not always required
// // //   image?: string;           // Optional, could be undefined or null
// // //   description?: string;     // Optional
// // //   stock: number;            // Default is 0 in the backend, but must be defined on the frontend
// // //   createdAt?: string;       // Optional, due to the `timestamps` field in mongoose schema
// // //   updatedAt?: string;       // Optional, due to the `timestamps` field in mongoose schema
// // // }

// // export interface Product {
// //   _id?: string;
// //   name: string;
// //   price: number;
// //   category?: string;
// //   brand: string;
// //   image?: string;
// //   description?: string;
// //   stock: number;
// //   createdAt?: string;
// //   updatedAt?: string;
// // }

// // src/app/models/product.model.ts
// export interface Product {
//   _id?: string;
//   name: string;
//   price: number;
//   category?: string;
//   brand: string;
//   image?: string;
//   description?: string;
//   stock: number;
//   rating?: number;           // ✅ Add this line to support product ratings
//   createdAt?: string;
//   updatedAt?: string;
// }

// export interface Product {
//   _id?: string;
//   name: string;
//   price: number;
//   category?: string;
//   brand: string;
//   image?: string;
//   description?: string;
//   stock: number;
//   rating?: number;
//   createdAt?: string;
//   updatedAt?: string;
//   status?: string; // ✅ Add this to prevent the template error
// }
export interface Product {
  _id?: string;
  name: string;
  price: number;
  category?: string;
  brand: string;

  image?: string; 
  description?: string;
  stock: number;
  rating?: number;
  createdAt?: string;
  updatedAt?: string;
  status?: string;
}

