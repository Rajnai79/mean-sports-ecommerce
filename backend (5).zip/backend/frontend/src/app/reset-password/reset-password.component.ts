import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  email = '';
  newPassword = '';
  message = '';
  isSuccess = false;

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.email = this.route.snapshot.queryParamMap.get('email') || '';
  }

  onSubmit() {
    this.http.post<any>('http://localhost:3000/reset-password', {
      email: this.email,
      newPassword: this.newPassword
    }).subscribe({
      next: (res) => {
        this.message = res.message;
        this.isSuccess = true;

        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (err) => {
        this.message = err.error.message || '❌ Failed to reset password.';
        this.isSuccess = false;
      }
    });
  }
}
