import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { productReviews } from './product-reviews';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) {}

  getProductById(id: string): Observable<any> {
    return this.http.get<any>(`/api/products/${id}`);
  }

  getProductReviews(productId: string): Observable<any[]> {
    return of(productReviews[productId] || []);
  }

  addToCart(product: any): Observable<any> {
    return this.http.post<any>('/api/cart', product);
  }

  submitReview(productId: string, review: any): Observable<any> {
    if (!productReviews[productId]) {
      productReviews[productId] = [];
    }
    productReviews[productId].push(review);
    return of({ success: true, message: 'Review added successfully' });
  }
}
