import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  username: string = '';
  email: string = '';
  password: string = '';
  message: string = '';
  isSuccess: boolean = false;
  isLoading: boolean = false;

  constructor(private http: HttpClient, private router: Router) {}

  onRegister() {
    if (!this.username || !this.email || !this.password) {
      this.showMessage('⚠️ All fields are required!', false);
      return;
    }

    if (!this.validateEmail(this.email)) {
      this.showMessage('❌ Invalid email format!', false);
      return;
    }

    if (this.password.length < 6) {
      this.showMessage('🔒 Password must be at least 6 characters!', false);
      return;
    }

    const userData = { username: this.username, email: this.email, password: this.password };
    this.isLoading = true;

    this.http.post<{ message: string }>('http://localhost:3000/register', userData).subscribe(
      (response) => {
        this.showMessage(response.message || '✅ Registration successful!', true);
        setTimeout(() => this.router.navigate(['/home2']), 2000);
      },
      (error) => {
        this.showMessage(error.error?.message || '❌ Registration failed. Try again!', false);
      }
    );
  }

  validateEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  private showMessage(msg: string, success: boolean) {
    this.message = msg;
    this.isSuccess = success;
    this.isLoading = false;
  }
}
