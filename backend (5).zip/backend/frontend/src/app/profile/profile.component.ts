
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  username: string = '';
  email: string = '';
  profileImage: string | null = null;
  errorMessage: string = '';

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedUsername = localStorage.getItem('username');
    const storedEmail = localStorage.getItem('email');
    const storedImage = localStorage.getItem('profileImage');

    if (!storedUsername) {
      this.router.navigate(['/login']);
    } else {
      this.username = storedUsername;
      this.email = storedEmail || '';
      this.profileImage = storedImage;
    }
  }

  updateProfile(): void {
    if (!this.username || !this.email) {
      this.errorMessage = 'Please fill in all required fields.';
      return;
    }

    localStorage.setItem('username', this.username);
    localStorage.setItem('email', this.email);
    if (this.profileImage) {
      localStorage.setItem('profileImage', this.profileImage);
    }

    this.errorMessage = '';
    alert('Profile updated successfully!');
  }

  onPhotoUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();

      reader.onload = () => {
        this.profileImage = reader.result as string;
      };

      reader.onerror = () => {
        this.errorMessage = 'Failed to load image. Please try again.';
      };

      reader.readAsDataURL(file);
    }
  }

  goBackToHome(): void {
    this.router.navigate(['/home2']);
  }

  logout(): void {
    localStorage.removeItem('username');
    localStorage.removeItem('email');
    localStorage.removeItem('profileImage');
    localStorage.removeItem('cart');
    this.router.navigate(['/login']);
  }
}
