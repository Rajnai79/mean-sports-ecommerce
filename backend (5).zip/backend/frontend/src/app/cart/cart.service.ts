import { Injectable } from '@angular/core';
import { CartItem } from './cart-item.model';

@Injectable({ providedIn: 'root' })
export class CartService {
  private cartKey = 'cart';

  getCart(): CartItem[] {
    const storedCart = localStorage.getItem(this.cartKey);
    return storedCart ? JSON.parse(storedCart) : [];
  }

  saveCart(cart: CartItem[]): void {
    const updatedCart = cart.map(item => ({
      ...item,
      imageUrl: item.image 
    }));
    localStorage.setItem(this.cartKey, JSON.stringify(updatedCart));
  }


  clearCart(): void {
    localStorage.removeItem(this.cartKey);
  }
}
