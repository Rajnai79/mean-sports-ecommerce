import { Component, OnInit } from '@angular/core';
import { sportsProducts } from '../home2/product-list';
@Component({
  selector: 'app-product-comparison',
  templateUrl: './product-comparison.component.html',
  styleUrls: ['./product-comparison.component.scss']
})
export class ProductComparisonComponent implements OnInit {
  sportsProducts = sportsProducts;
  availableProducts: any[] = [];
  selectedProducts: any[] = [];
  comparisonProducts: any[] = [];
  categories = Object.keys(sportsProducts);
  ngOnInit(): void {
    this.availableProducts = Object.values(sportsProducts).flat();
  }

  addToComparison(product: any): void {
    if (this.selectedProducts.length >= 4) {
      alert('You can only compare up to 4 products.');
      return;
    }
    if (!this.selectedProducts.includes(product)) {
      this.selectedProducts.push(product);
    }
    this.comparisonProducts = [...this.selectedProducts];
  }

  removeFromComparison(product: any): void {
    this.selectedProducts = this.selectedProducts.filter(p => p.name !== product.name);
    this.comparisonProducts = [...this.selectedProducts];
  }

  clearComparison(): void {
    this.selectedProducts = [];
    this.comparisonProducts = [];
  }
}

