// // product.service.ts

// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { BehaviorSubject } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class ProductService {
//   private productChange = new BehaviorSubject<void>(null);  // <- New line

//   constructor(private http: HttpClient) {}

//   getProducts() {
//     return this.http.get('/api/products');
//   }

//   addProduct(product: any) {
//     return this.http.post('/api/products', product);
//   }

//   // Notify other components when product list changes
//   notifyProductChange() {
//     this.productChange.next();
//   }

//   // Allow components to subscribe
//   onProductChange() {
//     return this.productChange.asObservable();
//   }
// }
// src/app/services/product.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../models/product.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private apiUrl = 'http://localhost:3000/api/products'; // change if deployed

  constructor(private http: HttpClient) {}

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

  addProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(this.apiUrl, product);
  }
}

