const express = require('express');
const multer = require('multer');
const path = require('path');
const Product = require('../models/product.model');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');  
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); 
  }
});

const upload = multer({ storage: storage });


router.post('/', upload.single('image'), async (req, res) => {
  const { name, price, category, brand, description, stock } = req.body;

  if (!name || !price) {
    return res.status(400).json({ message: '⚠️ Name and price are required.' });
  }

  const image = req.file ? req.file.path : '';  
  try {
    const newProduct = new Product({ name, price, category, brand, image, description, stock });
    const savedProduct = await newProduct.save();
    res.status(201).json(savedProduct);
  } catch (error) {
    res.status(500).json({ message: '❌ Error adding product.', error: error.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: '❌ Error fetching products.', error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const product = await Product.findById(id);
    if (!product) return res.status(404).json({ message: '❌ Product not found.' });
    res.json(product);
  } catch (error) {
    res.status(500).json({ message: '❌ Error fetching product.', error: error.message });
  }
});


router.put('/:id', upload.single('image'), async (req, res) => {
  const { id } = req.params;
  const { name, price, category, brand, description, stock } = req.body;
  
  
  const image = req.file ? req.file.path : undefined;

  try {
    const updatedProduct = await Product.findByIdAndUpdate(
      id, 
      { name, price, category, brand, image: image || undefined, description, stock },
      { new: true }  // Return the updated product
    );

    if (!updatedProduct) return res.status(404).json({ message: '❌ Product not found.' });

    res.json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: '❌ Error updating product.', error: error.message });
  }
});

// Delete a product
router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const deletedProduct = await Product.findByIdAndDelete(id);
    if (!deletedProduct) return res.status(404).json({ message: '❌ Product not found.' });
    res.json({ message: '✅ Product deleted successfully.' });
  } catch (error) {
    res.status(500).json({ message: '❌ Error deleting product.', error: error.message });
  }
});

module.exports = router;
