const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Admin = require('../models/admin.model'); // adjust path if needed

mongoose.connect('mongodb://localhost:27017/sss')
  .then(async () => {
    const existing = await Admin.findOne({ email: 'admin@example.com' });
    if (existing) {
      console.log('Admin already exists');
      process.exit();
    }

    const hashed = await bcrypt.hash('admin123', 10);
    const admin = new Admin({
      username: 'SuperAdmin',
      email: 'admin@example.com',
      password: hashed
    });

    await admin.save();
    console.log('Admin created');
    process.exit();
  })
  .catch(err => {
    console.error('DB error', err);
    process.exit(1);
  });
