// const express = require('express');
// const router = express.Router();
// const Product = require('../models/product.model');
// const adminAuth = require('../middleware/adminAuth.middleware');

// // Create a new product
// router.post('/products', adminAuth, async (req, res) => {
//   const { name, price, category, brand, description, imageUrl, stock } = req.body;
//   const product = new Product({ name, price, category, brand, description, imageUrl, stock });

//   try {
//     await product.save();
//     res.status(201).json({ message: 'Product created', product });
//   } catch (error) {
//     res.status(400).json({ message: 'Error creating product', error });
//   }
// });

// // Get all products
// router.get('/products', adminAuth, async (req, res) => {
//   try {
//     const products = await Product.find();
//     res.json(products);
//   } catch (error) {
//     res.status(500).json({ message: 'Error retrieving products', error });
//   }
// });

// // Edit a product
// router.put('/products/:id', adminAuth, async (req, res) => {
//   const { id } = req.params;
//   const { name, price, category, brand, description, imageUrl, stock } = req.body;

//   try {
//     const product = await Product.findByIdAndUpdate(id, { name, price, category, brand, description, imageUrl, stock }, { new: true });
//     res.json({ message: 'Product updated', product });
//   } catch (error) {
//     res.status(400).json({ message: 'Error updating product', error });
//   }
// });

// // Delete a product
// router.delete('/products/:id', adminAuth, async (req, res) => {
//   const { id } = req.params;

//   try {
//     await Product.findByIdAndDelete(id);
//     res.json({ message: 'Product deleted' });
//   } catch (error) {
//     res.status(400).json({ message: 'Error deleting product', error });
//   }
// });

// module.exports = router;

const express = require('express');
const router = express.Router();
const productController = require('../controllers/product.controller');
const adminAuth = require('../middleware/adminAuth.middleware');

router.post('/', adminAuth, productController.createProduct);
router.get('/', productController.getAllProducts);
router.get('/:id', productController.getProductById);
router.put('/:id', adminAuth, productController.updateProduct);
router.delete('/:id', adminAuth, productController.deleteProduct);

module.exports = router;
