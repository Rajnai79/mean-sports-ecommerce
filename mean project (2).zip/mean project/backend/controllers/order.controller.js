const Order = require('../models/order.model');
const jwt = require('jsonwebtoken');

exports.placeOrder = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Unauthorized' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const { items, total } = req.body;
    const order = new Order({ userId: decoded.id, items, total });
    await order.save();
    res.status(201).json({ message: 'Order placed' });
  } catch (err) {
    res.status(500).json({ message: 'Order failed', error: err.message });
  }
};

exports.getOrderHistory = async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Unauthorized' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const orders = await Order.find({ userId: decoded.id }).sort({ date: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: 'Fetch failed', error: err.message });
  }
};
