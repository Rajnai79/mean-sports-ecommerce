export const sportsProducts: { [key: string]: any[] } = {cricket: [
   {
    _id: "660f1d6540c70e001fc0c123",
    name: "Nike Football",
    brand: "Nike",
    category: "Football",
    price: 1200,
    description: "Top quality match football",
    image: "assets/images/nike-football.png"
  },
  { "name": "Cricket Bat", "price": 150, "image": "assets/Images/cricket/images (17).jpeg", "category": "Bat", "brand": "GM" },
  { "name": "Cricket Kit Bag", "price": 120, "image": "assets/Images/cricket/images (6).jpeg", "category": "Bag", "brand": "Shrey" },
  { "name": "Plastic Cricket Set", "price": 50, "image": "assets/Images/cricket/images (1).jpeg", "category": "Set", "brand": "Kookaburra" },
  { "name": "Batting Pads", "price": 60, "image": "assets/Images/cricket/images (3).jpeg", "category": "Gear", "brand": "Cosco" },
  { "name": "Batting Gloves", "price": 40, "image": "assets/Images/cricket/images (4).jpeg", "category": "Gear", "brand": "Shrey" },
  { "name": "Cricket Stumps Set", "price": 55, "image": "assets/Images/cricket/images (5).jpeg", "category": "Stumps", "brand": "Kookaburra" },
  { "name": "Cricket Backpack", "price": 80, "image": "assets/Images/cricket/images (15).jpeg", "category": "Bag", "brand": "SS" },
  { "name": "Cricket Helmet", "price": 90, "image": "assets/Images/cricket/download.jpg", "category": "Gear", "brand": "Masuri" },
  { "name": "Cricket Shoes", "price": 70, "image": "assets/Images/cricket/images (3).jpeg", "category": "Footwear", "brand": "Adidas" }
]
,
football: [
  { name: 'Football', price: 50, image: 'assets/Images/football/images (7).jpeg', category: 'Ball', brand: 'Puma' },
  { name: 'Football Kit', price: 75, image: 'assets/Images/football/download (9).jpeg', category: 'Apparel', brand: 'Nike' },
  { name: 'Football', price: 55, image: 'assets/Images/football/images (2).jpeg', category: 'Ball', brand: 'Adidas' },
  { name: 'Football Shoes', price: 60, image: 'assets/Images/football/images (3).jpeg', category: 'Footwear', brand: 'Nike' },
  { name: 'Football Jersey', price: 30, image: 'assets/Images/football/images (4).jpeg', category: 'Apparel', brand: 'Puma' },
  { name: 'Football Jersey', price: 30, image: 'assets/Images/football/images (5).jpeg', category: 'Apparel', brand: 'Puma' },
  { name: 'Football Shoes', price: 60, image: 'assets/Images/football/images (6).jpeg', category: 'Footwear', brand: 'Adidas' },
  { name: 'Football Shoes', price: 70, image: 'assets/Images/football/images.jpeg', category: 'Footwear', brand: 'Nike' },
  { name: 'Goalkeeper Gloves', price: 35, image: 'assets/Images/football/download.jpg', category: 'Gear', brand: 'Adidas' },
  { name: 'Shin Guards', price: 20, image: 'assets/Images/football/download.jpg', category: 'Gear', brand: 'Nike' }
],
tableTennis: [
  { name: "Table Tennis Racket", price: 30, image: "assets/Images/tableTennis/images (1).jpeg", category: "Racket", brand: "Butterfly" },
  { name: "Table Tennis Ball Pack", price: 10, image: "assets/Images/tableTennis/images (7).jpeg", category: "Ball", brand: "Stiga" },
  { name: "Table Tennis Table", price: 300, image: "assets/Images/tableTennis/images.jpeg", category: "Table", brand: "Joola" },
  { name: "Table Tennis Net", price: 15, image: "assets/Images/tableTennis/images.jpeg", category: "Accessories", brand: "DHS" },
  { name: "Table Tennis Shoes", price: 60, image: "assets/Images/tableTennis/images (8).jpeg", category: "Footwear", brand: "Butterfly" },
  { name: "Table Tennis Kit Bag", price: 40, image: "assets/Images/tableTennis/images (6).jpeg", category: "Bag", brand: "Stiga" },
  { name: "Table Tennis Racket Cover", price: 15, image: "assets/Images/tableTennis/download (8).jpeg", category: "Accessories", brand: "Joola" },
  { name: "Table Tennis Bat Cleaner", price: 8, image: "assets/Images/tableTennis/download (2).jpeg", category: "Accessories", brand: "Butterfly" },
  { name: "Table Tennis Shorts", price: 25, image: "assets/Images/tableTennis/images (9).jpeg", category: "Apparel", brand: "Stiga" },
  { name: "Table Tennis Shirt", price: 30, image: "assets/Images/tableTennis/images (1).jpeg", category: "Apparel", brand: "Butterfly" }
]
,
tennis: [
  { name: "Wilson Pro Staff Tennis Racket", price: 129.99, image: "assets/Images/tennis/wilson_pro_staff.jpeg", category: "Racket", brand: "Wilson" },
  { name: "Babolat Pure Drive Tennis Racket", price: 199.99, image: "assets/Images/tennis/babolat_pure_drive.jpeg", category: "Racket", brand: "Babolat" },
  { name: "Head Graphene Speed Racket", price: 179.99, image: "assets/Images/tennis/head_graphene_speed.jpeg", category: "Racket", brand: "Head" },
  { name: "Yonex Ezone 100 Racket", price: 189.99, image: "assets/Images/tennis/yonex_ezone_100.jpeg", category: "Racket", brand: "Yonex" },
  { name: "Dunlop CX 200 Racket", price: 159.99, image: "assets/Images/tennis/dunlop_cx_200.jpeg", category: "Racket", brand: "Dunlop" },
  { name: "Wilson US Open Balls", price: 9.99, image: "assets/Images/tennis/wilson_us_open_balls.jpeg", category: "Balls", brand: "Wilson" },
  { name: "Babolat Gold Balls", price: 10.99, image: "assets/Images/tennis/babolat_gold_championship.jpeg", category: "Balls", brand: "Babolat" },
  { name: "Head Tour Balls", price: 11.99, image: "assets/Images/tennis/head_tour_balls.jpeg", category: "Balls", brand: "Head" },
  { name: "Tennis Bag", price: 99.99, image: "assets/Images/tennis/tennis_bag.jpeg", category: "Bag", brand: "Wilson" },
  { name: "Tennis Shoes", price: 89.99, image: "assets/Images/tennis/tennis_shoes.jpeg", category: "Footwear", brand: "Nike" }
],
basketball: [
  { name: 'Basketball', price: 60, image: 'assets/Images/basketball/basketball.webp', category: 'Ball', brand: 'Adidas' },

  { name: 'Basketball Shoes - Blue & Pink', price: 130, image: 'assets/Images/basketball/download.jpg', category: 'Footwear', brand: 'Puma' },
  { name: 'Basketball Shoes - Orange & Green', price: 130, image: 'assets/Images/basketball/download.jpeg', category: 'Footwear', brand: 'Puma' },
  { name: 'Basketball Hoop - Door Mounted', price: 50, image: 'assets/Images/basketball/download (1).jpeg', category: 'Accessories', brand: 'Spalding' },
  { name: 'Basketball Hoop Set', price: 80, image: 'assets/Images/basketball/download (1).jpeg', category: 'Accessories', brand: 'Spalding' },
  { name: 'Basketball Jersey', price: 40, image: 'assets/Images/basketball/download (1).jpeg', category: 'Apparel', brand: 'Nike' },
  { name: 'Basketball Bag', price: 70, image: 'assets/Images/basketball/download (4).jpeg', category: 'Bag', brand: 'Under Armour' },
  { name: 'Basketball Net', price: 15, image: 'assets/Images/basketball/images.jpeg', category: 'Accessories', brand: 'Wilson' },
  { name: 'Basketball Socks', price: 10, image: 'assets/Images/basketball/download (4).jpeg', category: 'Apparel', brand: 'Nike' },
  { name: 'Wristbands', price: 5, image: 'assets/Images/basketball/download (3).jpeg', category: 'Accessories', brand: 'Adidas' }
]

};
