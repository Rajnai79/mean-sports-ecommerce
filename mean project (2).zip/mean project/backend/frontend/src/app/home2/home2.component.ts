// 15
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { sportsProducts } from './product-list';

@Component({
  selector: 'app-home2',
  templateUrl: './home2.component.html',
  styleUrls: ['./home2.component.scss']
})
export class Home2Component implements OnInit {

  username: string = 'User';
  greeting: string = '';
  cart: any[] = [];
  wishlist: any[] = [];
  recentlyViewed: any[] = [];
  dealProduct: any = null;
  darkMode: boolean = false;

  searchQuery: string = '';
  selectedSport: string = '';
  selectedBrand: string = 'all';
  selectedCategory: string = 'all';
  selectedSort: string = 'name';

  filteredProducts: any[] = [];
  dropdownOpen: boolean = false;

  sportsList: string[] = ['cricket', 'football', 'tennis', 'basketball', 'tableTennis'];
  brandsList: string[] = ['Nike', 'Adidas', 'Puma', 'Reebok', 'Under Armour'];

  sportsProducts = sportsProducts;

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedUser = localStorage.getItem('username');
    const storedCart = localStorage.getItem('cart');
    const storedWishlist = localStorage.getItem('wishlist');

    if (!storedUser) {
      this.router.navigate(['/login']);
    } else {
      this.username = storedUser;
      this.cart = storedCart ? JSON.parse(storedCart) : [];
      this.wishlist = storedWishlist ? JSON.parse(storedWishlist) : [];
      this.setGreeting();
      this.setDealProduct();
    }
  }

  setGreeting(): void {
    const hour = new Date().getHours();
    if (hour < 12) this.greeting = 'Good Morning';
    else if (hour < 18) this.greeting = 'Good Afternoon';
    else this.greeting = 'Good Evening';
  }

  setDealProduct(): void {
    const all = Object.values(this.sportsProducts).flat();
    this.dealProduct = all[Math.floor(Math.random() * all.length)];
  }

  toggleDarkMode(): void {
    this.darkMode = !this.darkMode;
    document.body.classList.toggle('dark-mode', this.darkMode);
  }

  toggleDropdown(): void {
    this.dropdownOpen = !this.dropdownOpen;
  }

  closeDropdown(): void {
    this.dropdownOpen = false;
  }

  selectSport(sport: string): void {
    this.selectedSport = sport;
    this.filterProducts();
  }

  filterProducts(): void {
    if (!this.selectedSport || !this.sportsProducts[this.selectedSport]) {
      this.filteredProducts = [];
      return;
    }

    this.filteredProducts = this.sportsProducts[this.selectedSport]
      .filter(product => product.name.toLowerCase().includes(this.searchQuery.toLowerCase()))
      .filter(product => this.selectedBrand === 'all' || product.brand === this.selectedBrand)
      .filter(product => this.selectedCategory === 'all' || product.category === this.selectedCategory);

    this.sortProducts();
  }

  sortProducts(): void {
    this.filteredProducts.sort((a, b) =>
      this.selectedSort === 'price' ? a.price - b.price : a.name.localeCompare(b.name)
    );
  }

  filterByBrand(event: any): void {
    this.selectedBrand = event.target.value;
    this.filterProducts();
  }

  filterByCategory(event: any): void {
    this.selectedCategory = event.target.value;
    this.filterProducts();
  }

  onSortChange(event: any): void {
    this.selectedSort = event.target.value;
    this.sortProducts();
  }

  getCategories(): string[] {
    return this.selectedSport && this.sportsProducts[this.selectedSport]
      ? [...new Set(this.sportsProducts[this.selectedSport].map(product => product.category))]
      : [];
  }

  addToCart(product: any, event: MouseEvent): void {
    event.stopPropagation();
    const existingItem = this.cart.find(item => item.name === product.name);
    existingItem ? existingItem.quantity++ : this.cart.push({ ...product, quantity: 1 });
    localStorage.setItem('cart', JSON.stringify(this.cart));
    alert(`${product.name} added to cart!`);
  }

  addToWishlist(product: any, event: MouseEvent): void {
    event.stopPropagation();
    if (!this.wishlist.some(item => item.name === product.name)) {
      this.wishlist.push(product);
      localStorage.setItem('wishlist', JSON.stringify(this.wishlist));
      alert(`${product.name} added to wishlist!`);
    }
  }

  goToProfile(): void {
    this.router.navigate(['/profile']);
  }

  updateProfile(): void {
    this.router.navigate(['/update-profile']);
  }

  goToProductDetail(product: any): void {
    const productId = product.id || product.name.toLowerCase().replace(/\s+/g, '-');
    this.recentlyViewed.unshift(product);
    this.recentlyViewed = this.recentlyViewed.slice(0, 5);
    this.router.navigate(['/product', productId]);
  }

  logout(): void {
    localStorage.removeItem('username');
    localStorage.removeItem('cart');
    localStorage.removeItem('wishlist');
    this.router.navigate(['/login']);
  }
}
