import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin-login',

  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent {
  email = '';
  password = '';
  error = '';

  constructor(private adminService: AdminService, private router: Router) {}

  login() {
    this.adminService.loginAdmin({ email: this.email, password: this.password }).subscribe({
      next: (res: any) => {
        localStorage.setItem('adminToken', res.token);
        this.router.navigate(['/admin/dashboard']);
      },
      error: () => {
        this.error = 'Invalid credentials';
      }
    });
  }
}
