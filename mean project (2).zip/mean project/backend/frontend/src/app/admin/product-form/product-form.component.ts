// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-product-form',
//   templateUrl: './product-form.component.html',
//   styleUrls: ['./product-form.component.scss']
// })
// export class ProductFormComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.scss']


})
export class ProductFormComponent implements OnInit {
  form: FormGroup;
  id: string | null = null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService
  ) {
    this.form = this.fb.group({
      name: [''],
      price: [''],
      category: [''],
      brand: [''],
      description: [''],
      imageUrl: [''],
      stock: ['']
    });
  }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id) {
      this.adminService.getProductById(this.id).subscribe(product => this.form.patchValue(product));
    }
  }

  submit() {
    if (this.id) {
      this.adminService.updateProduct(this.id, this.form.value).subscribe(() => this.router.navigate(['/admin/dashboard']));
    } else {
      this.adminService.addProduct(this.form.value).subscribe(() => this.router.navigate(['/admin/dashboard']));
    }
  }
}
