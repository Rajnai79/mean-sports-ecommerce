import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-wishlist',
  templateUrl: './cart-wishlist.component.html',
  styleUrls: ['./cart-wishlist.component.scss']
})
export class CartWishlistComponent implements OnInit {
  cart: any[] = [];
  wishlist: any[] = [];

  ngOnInit(): void {
    this.loadCart();
    this.loadWishlist();
  }

  loadCart(): void {
    const storedCart = localStorage.getItem('cart');
    this.cart = storedCart ? JSON.parse(storedCart) : [];
  }

  loadWishlist(): void {
    const storedWishlist = localStorage.getItem('wishlist');
    this.wishlist = storedWishlist ? JSON.parse(storedWishlist) : [];
  }

  removeFromCart(index: number): void {
    this.cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(this.cart));
  }

  removeFromWishlist(index: number): void {
    this.wishlist.splice(index, 1);
    localStorage.setItem('wishlist', JSON.stringify(this.wishlist));
  }
}
