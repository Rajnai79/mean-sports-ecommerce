import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.scss']
})
export class OrderHistoryComponent implements OnInit {
  orderHistory: any[] = [];

  constructor() { }

  ngOnInit(): void {
    const savedOrders = localStorage.getItem('orderHistory');
    this.orderHistory = savedOrders ? JSON.parse(savedOrders) : [];
  }
}
