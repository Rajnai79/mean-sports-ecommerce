export const productReviews: { [productId: string]: any[] } = {};
