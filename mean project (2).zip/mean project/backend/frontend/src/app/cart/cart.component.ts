import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  couponCode: string = '';
  discount: number = 0;
  couponMessage: string = '';
  estimatedDelivery: string = '';

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedCart = localStorage.getItem('cart');
    this.cart = storedCart ? JSON.parse(storedCart) : [];
    this.calculateDelivery();
  }

  calculateDelivery() {
    const now = new Date();
    const minDate = new Date(now.setDate(now.getDate() + 3)).toDateString();
    const maxDate = new Date(now.setDate(now.getDate() + 2)).toDateString();
    this.estimatedDelivery = `${minDate} - ${maxDate}`;
  }

  getTotalPrice(): number {
    const subtotal = this.cart.reduce((total, item) => total + item.price * item.quantity, 0);
    return subtotal - this.discount;
  }

  removeFromCart(item: any): void {
    this.cart = this.cart.filter(cartItem => cartItem.name !== item.name);
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.resetCoupon();
  }

  clearCart(): void {
    this.cart = [];
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.resetCoupon();
  }

  increaseQuantity(item: any): void {
    item.quantity++;
    localStorage.setItem('cart', JSON.stringify(this.cart));
  }

  decreaseQuantity(item: any): void {
    if (item.quantity > 1) {
      item.quantity--;
      localStorage.setItem('cart', JSON.stringify(this.cart));
    }
  }

  applyCoupon(): void {
    const validCoupons: { [code: string]: number } = {
      'SAVE10': 0.10,
      'SAVE50': 0.50,
      'GREEN20': 0.20
    };

    const subtotal = this.cart.reduce((total, item) => total + item.price * item.quantity, 0);

    if (this.couponCode.toUpperCase() in validCoupons) {
      const discountRate = validCoupons[this.couponCode.toUpperCase()];
      this.discount = Math.floor(subtotal * discountRate);
      this.couponMessage = `Coupon applied! You saved ₹${this.discount}.`;
    } else {
      this.discount = 0;
      this.couponMessage = 'Invalid coupon code.';
    }
  }

  resetCoupon(): void {
    this.discount = 0;
    this.couponCode = '';
    this.couponMessage = '';
  }

  proceedToPayment(): void {
    this.router.navigate(['/payment']);
  }
}
