import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  message: string = '';
  isSuccess: boolean = false;
  isLoading: boolean = false;
  showPassword: boolean = false;

  constructor(private http: HttpClient, private router: Router) {}

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  onLogin() {
    if (!this.email || !this.password) {
      this.message = '⚠️ Please enter both email and password!';
      this.isSuccess = false;
      return;
    }

    const loginData = { email: this.email, password: this.password };
    this.isLoading = true;

    this.http.post<{ message: string; user: any; token: string }>('http://localhost:3000/login', loginData).subscribe(
      (response) => {
        this.message = response.message || '✅ Login successful!';
        this.isSuccess = true;

        localStorage.setItem('username', response.user.username);
        localStorage.setItem('token', response.token);

        this.isLoading = false;
        this.router.navigate(['/home2']);
      },
      (error) => {
        this.isSuccess = false;
        this.isLoading = false;
        this.message = error.error?.message || '❌ Login failed. Please try again.';
      }
    );
  }
}
