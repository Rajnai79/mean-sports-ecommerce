
// 15.8:40

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;
  paymentMethod: string = '';

  cardNumber: string = '';
  expiryDate: string = '';
  cvv: string = '';
  upiId: string = '';

  paymentSuccess: boolean = false;

  orderDetails: any;

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedCart = localStorage.getItem('cart');
    this.cart = storedCart ? JSON.parse(storedCart) : [];

    this.totalPrice = this.cart.reduce((total, item) =>
      total + item.price * (item.quantity || 1), 0
    );
  }

  confirmPayment(): void {
    if (!this.paymentMethod) {
      alert("Please select a payment method.");
      return;
    }

    if (this.paymentMethod === 'card' && !this.validateCardDetails()) {
      alert("Please enter valid card details.");
      return;
    }

    if (this.paymentMethod === 'upi' && !this.validateUpiDetails()) {
      alert("Please enter a valid UPI ID.");
      return;
    }

    this.orderDetails = {
      date: new Date().toLocaleDateString(),
      total: this.totalPrice,
      paymentMethod: this.paymentMethod,
      items: this.cart
    };

    let orderHistory = JSON.parse(localStorage.getItem('orderHistory') || '[]');

    if (!Array.isArray(orderHistory)) {
      orderHistory = [];
    }

    orderHistory.push(this.orderDetails);

    localStorage.setItem('orderHistory', JSON.stringify(orderHistory));

    this.paymentSuccess = true;

    setTimeout(() => {
      alert("Payment successful! Thank you for your purchase.");
      localStorage.removeItem('cart');
      this.router.navigate(['/home2']);
    }, 3000);
  }

  validateCardDetails(): boolean {
    return (
      this.cardNumber.length === 19 &&
      this.expiryDate.length === 5 &&
      this.cvv.length === 3
    );
  }

  validateUpiDetails(): boolean {
    return this.upiId.includes('@');
  }
}
