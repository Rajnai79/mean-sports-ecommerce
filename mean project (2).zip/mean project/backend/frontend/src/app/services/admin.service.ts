import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private baseUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  loginAdmin(credentials: any) {
    return this.http.post(`${this.baseUrl}/api/admin/login`, credentials);
  }

  getProducts() {
    return this.http.get(`${this.baseUrl}/api/products`);
  }

  addProduct(product: any) {
    return this.http.post(`${this.baseUrl}/api/products`, product);
  }

  updateProduct(id: string, product: any) {
    return this.http.put(`${this.baseUrl}/api/products/${id}`, product);
  }

  deleteProduct(id: string) {
    return this.http.delete(`${this.baseUrl}/api/products/${id}`);
  }

  getProductById(id: string) {
    return this.http.get(`${this.baseUrl}/api/products/${id}`);
  }
}
