import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home1',
  templateUrl: './home1.component.html',
  styleUrls: ['./home1.component.scss']
})
export class Home1Component {
  sport = [
    {
      id: 1,
      name: "Cricket Bat",
      category: "Cricket",
      description: "Professional cricket bat made from premium wood.",
      price: 2000,
      image: "assets/images/cricket-bat.jpg"
    },
    {
      id: 2,
      name: "Football",
      category: "Football",
      description: "High-quality football suitable for all weather conditions.",
      price: 1500,
      image: "assets/images/football.jpg"
    }
  ];

  isNewUser: boolean = false;

  reasons = [
    {
      title: 'Premium Quality',
      description: 'We offer only the best sports gear for every player.',
      image: 'assets/images/quality.png'
    },
    {
      title: 'Fast Shipping',
      description: 'Get your products delivered in record time.',
      image: 'assets/images/shipping.png'
    },
    {
      title: 'Customer Support',
      description: '24/7 assistance for all your questions and issues.',
      image: 'assets/images/support.png'
    }
  ];

  constructor(private router: Router) {
    this.checkNewUser();
  }

  // Navigation methods
  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToRegister() {
    this.router.navigate(['/register']);
  }

  navigateToAbout() {
    this.router.navigate(['/about']);
  }

  navigateToShop() {
    this.router.navigate(['/shop']);
  }

  navigateToProductDetails(productId: number) {
    this.router.navigate(['/product-details', productId]);
  }

  checkNewUser() {
    const visited = localStorage.getItem('visited');
    if (!visited) {
      this.isNewUser = true;
      localStorage.setItem('visited', 'true');
    }
  }
}
